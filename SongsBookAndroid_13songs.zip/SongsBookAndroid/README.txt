Songs Book Android App
======================
This is a native Android Studio project for the Telugu Christian Songs Book.

Included:
- Front cover from the supplied image
- Song images 1,2,3,5,6,7,8,9,10,11
- Song 4 placeholder because its image was not supplied
- Song list, search by song number, favorites, share text, and simple home screen

How to build:
1. Open this folder in Android Studio.
2. Let Android Studio download the Android Gradle plugin/dependencies.
3. Build > Build APK(s).

If you send Song 4 image later, replace/add it as app/src/main/res/drawable/song_04.jpg and update the images array in MainActivity.java.
