package com.songsbook.telugu;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content; android.content.SharedPreferences prefs;
    final int MAROON=Color.rgb(122,13,24), GOLD=Color.rgb(215,169,40), CREAM=Color.rgb(255,247,230);
    int[] images={R.drawable.song_01,R.drawable.song_02,R.drawable.song_03,R.drawable.song_04,R.drawable.song_05,R.drawable.song_06,R.drawable.song_07,R.drawable.song_08,R.drawable.song_09,R.drawable.song_10,R.drawable.song_11,R.drawable.song_12,R.drawable.song_13};
    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("songs",0); showSplash();}
    TextView tv(String s,float sp,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setPadding(20,14,20,14); return t; }
    GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(r);return g;}
    Button button(String text){ Button b=new Button(this); b.setText(text); b.setTextSize(16); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setBackground(bg(MAROON,28)); return b; }
    void base(){ root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(CREAM); setContentView(root); }
    void showSplash(){ base(); ImageView cover=new ImageView(this); cover.setImageResource(R.drawable.front_cover); cover.setScaleType(ImageView.ScaleType.CENTER_CROP); root.addView(cover,new LinearLayout.LayoutParams(-1,0,1)); Button open=button("పాటల పుస్తకం తెరవండి  ▶"); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,65);p.setMargins(30,10,30,25);root.addView(open,p); open.setOnClickListener(v->showHome()); }
    void header(String title){ LinearLayout h=new LinearLayout(this);h.setGravity(Gravity.CENTER_VERTICAL);h.setBackgroundColor(MAROON); TextView titlev=tv(title,21,Color.WHITE);titlev.setTypeface(null,1);h.addView(titlev,new LinearLayout.LayoutParams(0,70,1));Button home=button("⌂");h.addView(home,new LinearLayout.LayoutParams(70,65));home.setOnClickListener(v->showHome());root.addView(h); }
    void showHome(){ base(); header("క్రీస్తు పునరుద్ధాన సంఘం"); TextView sub=tv("పాటల పుస్తకం",24,MAROON);sub.setGravity(Gravity.CENTER);sub.setTypeface(null,1);root.addView(sub); content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(22,10,22,20);root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        Button all=button("📖  అన్ని పాటలు"); content.addView(all,new LinearLayout.LayoutParams(-1,65)); all.setOnClickListener(v->showSongs());
        Space sp=new Space(this);content.addView(sp,new LinearLayout.LayoutParams(1,12));
        Button search=button("🔍  పాట వెతకండి"); content.addView(search,new LinearLayout.LayoutParams(-1,65)); search.setOnClickListener(v->showSearch());
        content.addView(new Space(this),new LinearLayout.LayoutParams(1,12));
        Button fav=button("♥  ఇష్టమైన పాటలు"); content.addView(fav,new LinearLayout.LayoutParams(-1,65)); fav.setOnClickListener(v->showFavorites());
        TextView q=tv("“కీర్తనలతోను, గీతములతోను ప్రభువును స్తుతించుడి.”\n— ఎఫెసీయులు 5:19",17,Color.DKGRAY);q.setGravity(Gravity.CENTER);content.addView(q,new LinearLayout.LayoutParams(-1,0,1));
    }
    void showSongs(){ base(); header("పాటల జాబితా"); LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(16,12,16,12); ScrollView sv=new ScrollView(this);sv.addView(list);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        for(int i=1;i<=13;i++){ final int n=i; Button b=button("పాట నంబర్ " + i); list.addView(b,new LinearLayout.LayoutParams(-1,62)); Space s=new Space(this);list.addView(s,new LinearLayout.LayoutParams(1,8)); b.setOnClickListener(v->showSong(n)); }
    }
    void showSong(int n){ base(); header("పాట నంబర్ " + n); ScrollView sv=new ScrollView(this); ImageView iv=new ImageView(this);iv.setImageResource(images[n-1]);iv.setAdjustViewBounds(true);iv.setScaleType(ImageView.ScaleType.FIT_CENTER);sv.addView(iv);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout bar=new LinearLayout(this);bar.setPadding(10,6,10,10); Button f=button(prefs.getBoolean("fav"+n,false)?"♥ ఇష్టమైనది":"♡ ఇష్టమైనదిగా సేవ్"); Button sh=button("↗ షేర్");bar.addView(f,new LinearLayout.LayoutParams(0,60,1));bar.addView(sh,new LinearLayout.LayoutParams(0,60,1));root.addView(bar); f.setOnClickListener(v->{boolean x=!prefs.getBoolean("fav"+n,false);prefs.edit().putBoolean("fav"+n,x).apply();f.setText(x?"♥ ఇష్టమైనది":"♡ ఇష్టమైనదిగా సేవ్");}); sh.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,"పాట నంబర్ "+n+" — క్రీస్తు పునరుద్ధాన సంఘం పాటల పుస్తకం");startActivity(Intent.createChooser(i,"షేర్ చేయండి"));}); }
    void showSearch(){ base(); header("పాట వెతకండి"); LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(20,20,20,20);root.addView(box); EditText e=new EditText(this);e.setHint("పాట నంబర్ (ఉదా: 1, 2, 11)");e.setInputType(2);box.addView(e,new LinearLayout.LayoutParams(-1,65));Button go=button("🔍 వెతకండి");box.addView(go,new LinearLayout.LayoutParams(-1,60)); TextView result=tv("",18,Color.DKGRAY);result.setGravity(Gravity.CENTER);box.addView(result,new LinearLayout.LayoutParams(-1,120));go.setOnClickListener(v->{try{int n=Integer.parseInt(e.getText().toString());if(n>=1&&n<=13){showSong(n);}else result.setText("1 నుండి 13 వరకు పాట నంబర్ ఇవ్వండి.");}catch(Exception x){result.setText("పాట నంబర్ ఇవ్వండి.");}}); }
    void showFavorites(){ base(); header("ఇష్టమైన పాటలు"); LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(16,12,16,12);root.addView(list,new LinearLayout.LayoutParams(-1,0,1)); boolean any=false;for(int i=1;i<=13;i++)if(prefs.getBoolean("fav"+i,false)){any=true;final int n=i;Button b=button("♥  పాట నంబర్ "+i);list.addView(b,new LinearLayout.LayoutParams(-1,62));b.setOnClickListener(v->showSong(n));}if(!any){TextView t=tv("ఇంకా ఇష్టమైన పాటలు లేవు.\nపాటను తెరిచి ♥ నొక్కండి.",18,Color.DKGRAY);t.setGravity(Gravity.CENTER);list.addView(t,new LinearLayout.LayoutParams(-1,0,1));}}
    @Override public void onBackPressed(){showHome();}
}
